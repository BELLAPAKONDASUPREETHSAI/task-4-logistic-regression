# Logistic Regression - Task 4

Used the Breast Cancer dataset to build a binary classification model using logistic regression.

## Tools Used
- Python
- Pandas
- Scikit-learn
- Matplotlib

## Steps Performed
1. Loaded and cleaned data
2. Trained logistic regression model
3. Evaluated using confusion matrix, classification report, and ROC-AUC score
4. Plotted ROC curve